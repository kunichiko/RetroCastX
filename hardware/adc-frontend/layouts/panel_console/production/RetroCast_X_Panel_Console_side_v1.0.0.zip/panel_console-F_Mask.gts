G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-10-26T02:23:44+09:00*
G04 #@! TF.ProjectId,panel_console,70616e65-6c5f-4636-9f6e-736f6c652e6b,v1.0.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-10-26 02:23:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H5*
X130000000Y-145000000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X105000000Y-110000000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X195000000Y-145000000D03*
G04 #@! TD*
G04 #@! TO.C,H2*
X195000000Y-55000000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X105000000Y-55000000D03*
G04 #@! TD*
M02*
